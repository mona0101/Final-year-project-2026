# SAQR Dashboard + Backend

SAQR = Smart Aerial Quantitative Reconnaissance.

This project contains:

- React + Tailwind frontend dashboard
- FastAPI backend prepared for the LogMel + MobileNet + ResNet late-fusion model
- Mock mode so the app runs immediately
- Real-model mode placeholders for your `.pth` files and `models/all_models.py`

## Run frontend

```bash
npm install
npm run dev
```

Frontend URL:

```txt
http://localhost:5173
```

## Run backend

```bash
cd backend
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Backend URL:

```txt
http://127.0.0.1:8000
```

API docs:

```txt
http://127.0.0.1:8000/docs
```

## Connect real model

The notebook references these files, but they were not included in the notebook upload:

```txt
backend/weights/Audio_LogMelCNN_64_weights.pth
backend/weights/Visual_MobileNet_weights.pth
backend/weights/ResNet_RF_weights.pth
backend/weights/LogMel_Mobile_ResNet_weights.pth
backend/models/all_models.py
```

After adding them, run backend in real model mode:

```bash
SAQR_USE_REAL_MODEL=1 uvicorn main:app --reload --port 8000
```

Windows PowerShell:

```powershell
$env:SAQR_USE_REAL_MODEL="1"
uvicorn main:app --reload --port 8000
```

## Notes

The frontend automatically tries the backend first. If the backend is not running, it falls back to local mock data.
