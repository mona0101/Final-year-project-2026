const links = [
  { key: "dashboard", label: "Dashboard", icon: "▦" },
  { key: "models", label: "Models", icon: "◈" },
  { key: "alerts", label: "Alerts", icon: "⚠" },
  { key: "upload", label: "Upload Media", icon: "☁" },
];

export default function Sidebar({ activePage, setActivePage }) {
  return (
    <aside className="hidden md:flex w-64 min-h-[calc(100vh-5rem)] bg-white/85 border-r border-slate-200 p-5 flex-col gap-4">
      {links.map((link) => (
        <button
          key={link.key}
          onClick={() => setActivePage(link.key)}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition ${
            activePage === link.key
              ? "bg-blue-50 text-blue-600 border border-blue-200 shadow-sm"
              : "text-slate-500 hover:bg-slate-50 hover:text-blue-600"
          }`}
        >
          <span>{link.icon}</span>
          {link.label}
        </button>
      ))}

      <div className="mt-8 bg-sky-50 border border-sky-100 rounded-2xl p-4">
        <h3 className="font-bold text-blue-600 mb-2">Mission Mode</h3>
        <p className="text-sm text-slate-600 leading-relaxed">
          Multi-modal AI monitoring using Audio, Video, and RF fusion.
        </p>
      </div>
    </aside>
  );
}