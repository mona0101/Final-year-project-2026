export default function LoadingSpinner({ label = "Loading SAQR telemetry..." }) {
  return (
    <div className="flex min-h-72 flex-col items-center justify-center gap-4">
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-700 border-t-cyan-400" />
      <p className="text-sm text-slate-400">{label}</p>
    </div>
  );
}
