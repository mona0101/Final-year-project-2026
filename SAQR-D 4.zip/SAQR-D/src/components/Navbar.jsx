export default function Navbar() {
  return (
    <nav className="h-20 bg-white/90 backdrop-blur border-b border-slate-200 px-6 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 font-bold">
          ✦
        </div>

        <div>
          <h1 className="text-2xl font-bold tracking-[0.35em] text-blue-600">
            SAQR
          </h1>
          <p className="text-sm text-slate-500">
            Smart Aerial Quantitative Reconnaissance
          </p>
        </div>
      </div>

      <div className="px-5 py-2 rounded-full bg-green-50 border border-green-200 text-green-600 font-semibold">
        ● System Online
      </div>
    </nav>
  );
}