const styles = {
  Active: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300",
  Inactive: "border-slate-500/40 bg-slate-500/10 text-slate-300",
  High: "border-red-400/50 bg-red-500/10 text-red-300",
  Medium: "border-amber-400/50 bg-amber-500/10 text-amber-300",
  Low: "border-emerald-400/50 bg-emerald-500/10 text-emerald-300",
  Detected: "border-red-400/50 bg-red-500/10 text-red-300",
  "Not Detected": "border-emerald-400/50 bg-emerald-500/10 text-emerald-300",
};

export default function StatusBadge({ status }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${styles[status] || styles.Inactive}`}>
      {status}
    </span>
  );
}
