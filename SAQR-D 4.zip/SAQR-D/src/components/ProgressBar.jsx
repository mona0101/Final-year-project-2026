export default function ProgressBar({ value, label }) {
  return (
    <div>
      {label && (
        <div className="mb-2 flex items-center justify-between text-sm text-slate-300">
          <span>{label}</span>
          <span>{value}%</span>
        </div>
      )}
      <div className="h-2 overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400 shadow-[0_0_18px_rgba(34,211,238,0.8)] transition-all duration-700"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
