
export default function Card({ title, subtitle, children }) {
  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
      <h3 className="text-slate-700 font-semibold">{title}</h3>
      {subtitle && <p className="text-sm text-slate-500 mb-3">{subtitle}</p>}
      {children}
    </div>
  );
}