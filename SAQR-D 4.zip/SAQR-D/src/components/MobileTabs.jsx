const links = [
  { key: "dashboard", label: "Dashboard" },
  { key: "models", label: "Models" },
  { key: "alerts", label: "Alerts" },
  { key: "upload", label: "Upload" },
];

export default function MobileTabs({ activePage, setActivePage }) {
  return (
    <div className="md:hidden bg-white border-b border-slate-200 p-3 flex gap-2 overflow-x-auto">
      {links.map((link) => (
        <button
          key={link.key}
          onClick={() => setActivePage(link.key)}
          className={`px-4 py-2 rounded-full text-sm font-semibold ${
            activePage === link.key
              ? "bg-blue-100 text-blue-700"
              : "bg-slate-50 text-slate-500"
          }`}
        >
          {link.label}
        </button>
      ))}
    </div>
  );
}