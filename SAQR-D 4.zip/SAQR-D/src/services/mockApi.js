import { alerts, detectionData } from "../data/mockData";

const API_URL = import.meta.env.VITE_SAQR_API_URL || "http://127.0.0.1:8000";

const delay = (payload, ms = 500) =>
  new Promise((resolve) => {
    setTimeout(() => resolve(payload), ms);
  });

async function fetchJson(endpoint, fallback) {
  try {
    const response = await fetch(`${API_URL}${endpoint}`);
    if (!response.ok) throw new Error(`API error ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn(`Using local mock data because backend is unavailable: ${error.message}`);
    return delay(fallback);
  }
}

export const fetchDetectionData = () => fetchJson("/api/detect/latest", detectionData);
export const fetchAlerts = () => fetchJson("/api/alerts", alerts);
export const fetchModels = async () => {
  const data = await fetchDetectionData();
  return data.models || detectionData.models;
};
