export default function Upload() {
  return (
    <div>
      <h1 className="text-3xl font-extrabold text-slate-900 mb-2">
        Upload Media
      </h1>
      <p className="text-slate-500 mb-6">
        Upload audio, video, image, or RF signal files for analysis.
      </p>

      <div className="bg-white border border-slate-200 rounded-3xl shadow-sm p-8">
        <div className="border-2 border-dashed border-blue-200 bg-blue-50/50 rounded-3xl p-10 text-center">
          <div className="text-5xl mb-4">☁</div>

          <h2 className="text-2xl font-bold text-blue-600 mb-2">
            Upload File for Detection
          </h2>

          <p className="text-slate-500 mb-6">
            Select a file to analyze using SAQR multi-modal AI system.
          </p>

          <input
            type="file"
            className="block mx-auto text-sm text-slate-600
            file:mr-4 file:py-3 file:px-5
            file:rounded-full file:border-0
            file:bg-blue-600 file:text-white
            file:font-semibold
            hover:file:bg-blue-700"
          />

          <button className="mt-6 px-6 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition">
            Analyze File
          </button>
        </div>
      </div>
    </div>
  );
}