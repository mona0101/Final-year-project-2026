const Card = ({ children }) => (
  <div className="bg-white/95 border border-slate-200 rounded-2xl shadow-sm p-5">
    {children}
  </div>
);

const ProgressBar = ({ value }) => (
  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
    <div
      className="h-full bg-blue-500 rounded-full"
      style={{ width: `${value}%` }}
    />
  </div>
);

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <section className="bg-white/95 border border-blue-100 rounded-3xl shadow-sm p-8 flex flex-col lg:flex-row justify-between gap-6">
        <div>
          <p className="text-blue-600 tracking-[0.4em] font-bold text-sm mb-4">
            REAL-TIME COMMAND CENTER
          </p>
          <h1 className="text-4xl font-extrabold text-slate-900 mb-3">
            SAQR Dashboard
          </h1>
          <p className="text-slate-600 max-w-2xl leading-relaxed">
            Smart Aerial Quantitative Reconnaissance monitors drone threats
            using Audio, Video, and RF artificial intelligence models.
          </p>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6 min-w-[280px] text-center">
          <p className="text-blue-600 font-bold tracking-widest text-sm">
            CURRENT DETECTION
          </p>
          <h2 className="text-3xl font-extrabold text-blue-700 mt-3">
            Drone Detected
          </h2>
          <p className="text-slate-500 mt-1">Fusion confidence 92%</p>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <Card>
          <p className="text-slate-500 mb-3">Detection Status</p>
          <span className="px-3 py-1 rounded-full bg-green-50 border border-green-200 text-green-600 text-sm font-bold">
            DETECTED
          </span>
        </Card>

        <Card>
          <p className="text-slate-500 mb-3">Threat Level</p>
          <span className="px-3 py-1 rounded-full bg-red-50 border border-red-200 text-red-500 text-sm font-bold">
            HIGH
          </span>
        </Card>

        <Card>
          <p className="text-slate-500 mb-3">Monitoring Zone</p>
          <h3 className="text-2xl font-bold text-blue-600">
            North Perimeter
          </h3>
        </Card>

        <Card>
          <p className="text-slate-500 mb-3">Last Detection</p>
          <p className="font-semibold text-slate-700">
            2026-04-25 21:48:12
          </p>
        </Card>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {[
          ["Audio Model", "CNN - LogMel", "Drone Sound Detected", 92, "Audio Spectrogram"],
          ["Video Model", "MobileNet", "Drone Object Detected", 87, "Live Camera Feed"],
          ["RF Model", "ResNet", "Drone RF Signature Detected", 96, "RF Signal"],
        ].map(([title, model, result, confidence, input]) => (
          <Card key={title}>
            <h3 className="text-xl font-bold text-slate-800">{title}</h3>
            <p className="text-slate-500 mb-5">{model}</p>

            <p className="text-slate-600 mb-4">{result}</p>

            <div className="flex justify-between mb-2">
              <span className="text-slate-500">Confidence</span>
              <span className="font-bold text-slate-700">{confidence}%</span>
            </div>

            <ProgressBar value={confidence} />

            <div className="flex justify-between items-center mt-5">
              <p className="text-slate-500">Input: {input}</p>
              <span className="px-3 py-1 rounded-full bg-green-50 border border-green-200 text-green-600 text-xs font-bold">
                ACTIVE
              </span>
            </div>
          </Card>
        ))}
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card>
          <h3 className="text-xl font-bold text-blue-600">
            Fusion Result Card
          </h3>
          <p className="text-slate-500 mb-5">Final decision from all models</p>

          <div className="flex justify-between mb-4">
            <span className="text-slate-600">Decision</span>
            <span className="text-2xl font-bold text-blue-600">
              Drone Detected
            </span>
          </div>

          <div className="flex justify-between mb-2">
            <span className="text-slate-600">Fusion Confidence</span>
            <span className="font-bold">92%</span>
          </div>

          <ProgressBar value={92} />

          <p className="text-slate-500 mt-5 leading-relaxed">
            The fusion engine combines Audio CNN-LogMel, Video MobileNet, and RF
            ResNet outputs into one final threat decision.
          </p>
        </Card>

        <Card>
          <h3 className="text-xl font-bold text-blue-600">
            Live Confidence Matrix
          </h3>
          <p className="text-slate-500 mb-5">Model confidence comparison</p>

          {[
            ["Audio Model", 92],
            ["Video Model", 87],
            ["RF Model", 96],
          ].map(([name, value]) => (
            <div key={name} className="mb-5">
              <div className="flex justify-between mb-2">
                <span className="text-slate-600">{name}</span>
                <span className="font-bold">{value}%</span>
              </div>
              <ProgressBar value={value} />
            </div>
          ))}
        </Card>
      </section>
    </div>
  );
}