const models = [
  {
    name: "Audio Model",
    type: "Audio Spectrogram",
    architecture: "CNN - LogMel",
    accuracy: "92%",
    status: "Active",
  },
  {
    name: "Video Model",
    type: "Image / Video Frame",
    architecture: "MobileNet",
    accuracy: "87%",
    status: "Active",
  },
  {
    name: "RF Model",
    type: "Radio Frequency Signal",
    architecture: "ResNet",
    accuracy: "96%",
    status: "Active",
  },
];

export default function Models() {
  return (
    <div>
      <h1 className="text-3xl font-extrabold text-slate-900 mb-2">
        AI Models
      </h1>
      <p className="text-slate-500 mb-6">
        Overview of SAQR detection models.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {models.map((model) => (
          <div
            key={model.name}
            className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6"
          >
            <h2 className="text-xl font-bold text-blue-600 mb-4">
              {model.name}
            </h2>

            <div className="space-y-3 text-slate-600">
              <p><b>Input Type:</b> {model.type}</p>
              <p><b>Architecture:</b> {model.architecture}</p>
              <p><b>Accuracy:</b> {model.accuracy}</p>
            </div>

            <span className="inline-block mt-5 px-3 py-1 rounded-full bg-green-50 border border-green-200 text-green-600 text-sm font-bold">
              {model.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}