const alerts = [
  {
    id: 1,
    title: "Drone Detected",
    zone: "North Perimeter",
    level: "High",
    time: "2026-04-25 21:48:12",
  },
  {
    id: 2,
    title: "RF Signature Detected",
    zone: "East Zone",
    level: "Medium",
    time: "2026-04-25 20:13:04",
  },
  {
    id: 3,
    title: "Audio Pattern Detected",
    zone: "Main Gate",
    level: "Low",
    time: "2026-04-25 18:40:22",
  },
];

export default function Alerts() {
  return (
    <div>
      <h1 className="text-3xl font-extrabold text-slate-900 mb-2">
        Alerts
      </h1>
      <p className="text-slate-500 mb-6">
        Recent drone detection events.
      </p>

      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 flex flex-col md:flex-row justify-between gap-4"
          >
            <div>
              <h2 className="text-xl font-bold text-blue-600">
                {alert.title}
              </h2>
              <p className="text-slate-500">Zone: {alert.zone}</p>
              <p className="text-slate-500">Time: {alert.time}</p>
            </div>

            <span className="h-fit px-4 py-2 rounded-full bg-red-50 border border-red-200 text-red-500 font-bold">
              {alert.level}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}