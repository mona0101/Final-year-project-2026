import { useState } from "react";

export default function App() {
  const [mediaFile, setMediaFile] = useState(null);
  const [result, setResult] = useState(null);

  const handleAnalyze = () => {
    if (!mediaFile) {
      alert("Please upload a media file before analysis.");
      return;
    }

    setResult({
      decision: "Drone Detected",
      confidence: 90,
      audioConfidence: 5,
      visualConfidence: 90,
      rfConfidence: 0,
      fileType: mediaFile.type || "Unknown file type",
      fileName: mediaFile.name,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-sky-50 to-blue-50 text-slate-800">
      <header className="bg-white border-b border-slate-200 px-8 py-5 text-center">
        <h1 className="text-3xl font-black text-blue-600">
          Multi-Modal Drone Detection System
        </h1>
        <p className="text-slate-500 mt-1">
          Upload one media file for audio, visual, and RF-based analysis
        </p>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <section className="bg-white border border-slate-200 rounded-3xl shadow-sm p-8">
          <div className="text-center mb-6">
            <p className="text-sm font-bold uppercase tracking-[0.3em] text-blue-500">
              Unified Multi-Modal Input
            </p>

            <h2 className="text-3xl font-black text-slate-900 mt-3">
              One Upload → Three AI Analyses
            </h2>

            <p className="text-slate-500 mt-3">
              Upload a single media file and the system will automatically
              analyze audio, visual, and RF detection confidence.
            </p>

            <div className="flex flex-wrap justify-center gap-3 mt-5">
              <span className="px-4 py-2 bg-blue-50 border border-blue-200 rounded-full text-blue-600 text-sm font-semibold">
                Audio Analysis
              </span>

              <span className="px-4 py-2 bg-blue-50 border border-blue-200 rounded-full text-blue-600 text-sm font-semibold">
                Visual Analysis
              </span>

              <span className="px-4 py-2 bg-blue-50 border border-blue-200 rounded-full text-blue-600 text-sm font-semibold">
                Radio Frequency Analysis
              </span>
            </div>
          </div>

          <label className="block cursor-pointer rounded-3xl border-2 border-dashed border-blue-200 bg-blue-50/60 p-10 text-center hover:bg-blue-50 transition">
            <span className="block text-5xl mb-4">☁</span>

            <span className="block text-xl font-bold text-blue-600">
              Upload Media File
            </span>

            <span className="block mt-2 text-sm text-slate-500">
              Supported files: image, video, audio, Radio Frequency
            </span>

            <input
              type="file"
              accept="audio/*,image/*,video/*,.csv,.txt,.wav,.mp3,.mp4,.jpg,.jpeg,.png"
              className="hidden"
              onChange={(e) => {
                setMediaFile(e.target.files[0]);
                setResult(null);
              }}
            />
          </label>

          {mediaFile && (
            <div className="mt-5 bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
              <p className="text-sm text-slate-500">Selected File</p>
              <p className="font-bold text-slate-800 truncate">
                {mediaFile.name}
              </p>
              <p className="text-sm text-slate-500">
                Type: {mediaFile.type || "Unknown"}
              </p>
            </div>
          )}

          <button
            onClick={handleAnalyze}
            className="mt-6 w-full py-4 rounded-2xl bg-blue-600 text-white font-bold text-lg shadow-sm hover:bg-blue-700 transition"
          >
            Analyze Media
          </button>
        </section>

        {result && (
          <section className="mt-8 bg-white border border-blue-100 rounded-3xl shadow-sm p-8">
            <h3 className="text-2xl font-black text-slate-900 mb-6">
              Detection Result
            </h3>

            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6 text-center mb-6">
              <p className="text-sm uppercase tracking-widest text-blue-600 font-bold">
                Final Decision
              </p>

              <h2 className="mt-2 text-4xl font-black text-blue-700">
                {result.decision}
              </h2>

              <p className="mt-2 text-slate-500">
                Overall Confidence: {result.confidence}%
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <ConfidenceCard
                title="Audio Detection"
                value={result.audioConfidence}
              />

              <ConfidenceCard
                title="Visual Detection"
                value={result.visualConfidence}
              />

              <ConfidenceCard title="RF Detection" value={result.rfConfidence} />
            </div>
          </section>
        )}

        {result && result.decision === "Drone Detected" && <TrackingPanel />}
      </main>
    </div>
  );
}

function ConfidenceCard({ title, value }) {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-bold text-slate-800">{title}</h4>
        <span className="font-black text-blue-600">{value}%</span>
      </div>

      <div className="h-2 w-full rounded-full bg-slate-200 overflow-hidden">
        <div
          className="h-full rounded-full bg-blue-500"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

function TrackingPanel() {
  const tracks = [
    {
      id: "ID1",
      color: "#3b82f6",
      points: [
        { x: 160, y: 185 },
        { x: 210, y: 182 },
        { x: 260, y: 176 },
        { x: 310, y: 165 },
      ],
    },
    {
      id: "ID2",
      color: "#14b8a6",
      points: [
        { x: 170, y: 30 },
        { x: 170, y: 65 },
        { x: 175, y: 80 },
      ],
    },
    {
      id: "ID3",
      color: "#eab308",
      points: [
        { x: 270, y: 125 },
        { x: 295, y: 112 },
        { x: 330, y: 95 },
      ],
    },
    {
      id: "ID4",
      color: "#ef4444",
      points: [
        { x: 165, y: 135 },
        { x: 172, y: 133 },
      ],
    },
    {
      id: "ID5",
      color: "#22c55e",
      points: [
        { x: 210, y: 100 },
        { x: 215, y: 102 },
      ],
    },
    {
      id: "ID6",
      color: "#fb7185",
      points: [
        { x: 45, y: 170 },
        { x: 55, y: 178 },
        { x: 65, y: 180 },
      ],
    },
  ];

  const createPath = (points) =>
    points
      .map((point, index) =>
        index === 0 ? `M ${point.x} ${point.y}` : `L ${point.x} ${point.y}`
      )
      .join(" ");

  return (
    <section className="mt-8 bg-white border border-blue-100 rounded-3xl shadow-sm p-8">
      <div className="mb-6">
        <p className="text-sm font-bold uppercase tracking-[0.25em] text-blue-500">
          Drone Tracking
        </p>

        <h3 className="text-2xl font-black text-slate-900 mt-2">
          UAV Track Trajectories
        </h3>

        <p className="text-slate-500 mt-2">
          Estimated drone movement path based on tracked frames.
        </p>
      </div>

      <div className="bg-slate-950 rounded-2xl p-5 overflow-hidden border border-slate-800">
        <svg viewBox="0 0 380 240" className="w-full h-72">
          {[40, 80, 120, 160, 200].map((y) => (
            <line
              key={`h-${y}`}
              x1="30"
              y1={y}
              x2="360"
              y2={y}
              stroke="#1e293b"
              strokeWidth="1"
            />
          ))}

          {[80, 140, 200, 260, 320].map((x) => (
            <line
              key={`v-${x}`}
              x1={x}
              y1="20"
              x2={x}
              y2="210"
              stroke="#1e293b"
              strokeWidth="1"
            />
          ))}

          <line x1="30" y1="210" x2="360" y2="210" stroke="#64748b" />
          <line x1="30" y1="20" x2="30" y2="210" stroke="#64748b" />

          <text x="140" y="14" fill="#e2e8f0" fontSize="10">
            UAV Track Trajectories
          </text>

          <text x="180" y="232" fill="#cbd5e1" fontSize="9">
            X pixel
          </text>

          <text
            x="-135"
            y="12"
            fill="#cbd5e1"
            fontSize="9"
            transform="rotate(-90)"
          >
            Y pixel
          </text>

          {tracks.map((track) => {
            const lastPoint = track.points[track.points.length - 1];

            return (
              <g key={track.id}>
                <path
                  d={createPath(track.points)}
                  fill="none"
                  stroke={track.color}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {track.points.map((point, index) => (
                  <circle
                    key={index}
                    cx={point.x}
                    cy={point.y}
                    r={index === track.points.length - 1 ? 4 : 3}
                    fill={track.color}
                  />
                ))}

                <text
                  x={lastPoint.x + 6}
                  y={lastPoint.y + 4}
                  fill={track.color}
                  fontSize="9"
                  fontWeight="bold"
                >
                  {track.id}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
        <TrackingInfo title="Tracked Objects" value="6 UAV Tracks" />
        <TrackingInfo title="Tracked Frames" value="42 Frames" />
        <TrackingInfo title="Status" value="Tracking Active" />
      </div>
    </section>
  );
}

function TrackingInfo({ title, value }) {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
      <p className="text-sm text-slate-500">{title}</p>
      <p className="font-black text-slate-900 mt-1">{value}</p>
    </div>
  );
}